import Image from "next/image"

export default function Hero() {
  return (
    <section className="relative h-screen w-full overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="https://sjc.microlink.io/qZEI0wOhXZGBVq_KOpFvvu23rXOCQ8s_31Tf2NzZVVtWODtqzHoBjwdf36PT170w9fo2D2Z8Wx99bQrGG-UZjQ.jpeg"
          alt="Skyscrapers viewed from below against blue sky"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/20" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex items-center justify-center h-full">
        <div className="text-center">
          <h1 className="text-white text-4xl md:text-5xl lg:text-6xl font-light tracking-[0.2em] leading-tight">
            WACHTELL, LIPTON, ROSEN & KATZ
          </h1>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-bounce" />
        </div>
      </div>
    </section>
  )
}
