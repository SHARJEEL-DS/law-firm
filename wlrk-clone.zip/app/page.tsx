import Hero from "@/components/hero"

export default function HomePage() {
  return (
    <div>
      <Hero />
    </div>
  )
}
